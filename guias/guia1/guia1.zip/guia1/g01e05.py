#5- Leer dos numeros reales y mostrarlos en orden creciente.
numero1 = int(input("escriba un numero: "))
numero2 = int(input("escriba otro numero: "))
if numero1 > numero2:
    print(numero1, numero2)
else:
    print(numero2, numero1)

    