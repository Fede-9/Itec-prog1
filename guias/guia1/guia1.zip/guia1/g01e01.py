#1- Pedir dos numeros enteros, sumarlos y mostrar el resultado.

numero1 = int(input("ingrese un numero: "))
numero2 = int(input("ingrese otro numero: "))
suma = numero1 + numero2
print("resultado:",suma)

