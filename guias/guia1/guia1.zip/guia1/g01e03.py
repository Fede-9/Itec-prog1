#3- Leer un numero real y emitir una leyenda informando si es mayor o igual a cero o bien es negativo 
# (son dos opciones).

numeroreal = int(input("ingrese un numero: "))
if numeroreal > 0:
 print("el numero real es mayor a 0")
elif numeroreal == 0:
    print("el numero real es igual que 0")
else:
    print("el numero real es negativo")
    
