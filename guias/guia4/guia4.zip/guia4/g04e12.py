#12. Mostrar el valor doble del número de dos cifras (que es el único número) encontrado en la cadena.
 #Ej.: 'Juan tiene 25 años' mostraría el número 50, ‘El dólar va a llegar este mes a 57 pesos casi seguro’,  mostraría 114.

cadena = 'Fede tiene 100 pesos'
cadena1 = cadena.split()
valor= (int(cadena1[2]) * 2)   #convierto el valor de la lista en un entero
doble = 'Fede tiene {} pesos'
print(doble.format(valor))