# 13. Pedir el ingreso de un nombre completo en la forma <nombre> <apellido>
# (ejemplo: Juan Pérez) y mostrarlo invertido y con coma <apellido>,<nombre> (ejemplo: Perez, Juan).

nombre_completo = input('Ingrese su nombre y apellido: ')
nombre = nombre_completo.title()  #mayuscula en la primera letra de cada palabra
nombre1 = nombre.split() #convierto en lista
nombre1.reverse()
invertido = ', '.join(nombre1) #uno lista para hacer cadena
print(invertido)