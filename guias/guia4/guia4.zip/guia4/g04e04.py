#Pasar una palabra a mayúsculas cambiando los caracteres uno por uno usando
#  la tabla ASCII de referencia (googlear la tabla y las funciones de conversión en Python).

cadena = "fede"
print(cadena[2])



    
