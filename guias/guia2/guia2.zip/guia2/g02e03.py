#Mostrar por pantalla una lista de 20 números enteros consecutivos, comenzando con un número
#  ingresado por teclado.
numero = int(input("ingrese un numero entero: "))
for x in range(numero, numero + 20):
    print(x)
