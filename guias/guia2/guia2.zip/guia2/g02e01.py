#Mostrar por pantalla los primeros 5 números naturales.
for x in range(1,6):
    print(x)
