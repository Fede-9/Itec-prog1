#Pedir nombres y sexo de personas y mostrar el total de mujeres y el nombre de cada una.
total = int(input("cuantas persona desea registrar? "))
nombre1 = []
x = 0
cont = 0
femenino = 1
while total != x:
    nombre2 = input("digame su nombre: ")
    sexo = int(input("si es sexo femenino marque '1' de lo contarrio marque '0': "))
    x += 1
    if sexo == 1:
        cont += 1
        nombre1.append(nombre2)
    
print("total de mujeres: ", cont)
print("nombre de cada una: " , nombre1)