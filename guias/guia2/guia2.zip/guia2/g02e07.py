#Mostrar los primeros 35 múltiplos de 5.
for multiplo in range(1,36):
    print(5 * multiplo)
    