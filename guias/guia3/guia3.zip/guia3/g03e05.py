#Guardar en una lista los números pares mayores que 0 y menores que 31. 

preg1 = input("desea ingresar un numero? ")
numeros = []

while preg1 == 'si':
    preg2 = int(input("ingrese un numero: "))
    if preg2 > 0 and preg2 < 31 and preg2%2 == 0:
        numeros.append(preg2)

    preg1 = input("desea ingresar otro numero? ")
    
print("el o los numeros pares ingresados son: ", numeros)