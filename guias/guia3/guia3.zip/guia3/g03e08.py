#Cargar una lista con números. Invertir los elementos sin usar otra lista

preg1 = int(input("cuantos numeros desea ingresar? "))
lista = []

for i in range(preg1):
    preg2 = int(input("ingrese un numero: "))
    lista.append(preg2)

print("numeros ingresados: ", lista)
print("numeros invertidos: ",lista[::-1])