#Cargar letras en una lista (while). Contar las vocales (for). Mostrar el total.

preg1 = input("Desea ingresar una letra?: ")
lista = []
vocal = 0


while preg1 == 'si':
    letra = input("ingrese una letra: ")
    lista.append(letra)
    preg1 = input("Desea ingresar otra letra?: ")
    
for x in lista:
    if x == 'a' or x == 'e' or x == 'i' or x == 'o' or x == 'u':
        vocal += 1

print("cantidad de vocales: ",vocal)