#Dada una lista cargada con 7 números enteros, obtener el promedio. 
# Mostrar por pantalla dicho promedio y los números de la lista que sean mayores que él.
num = []
suma = 0

for x in range(1,8):
    numero = int(input("ingrese un numero: "))
    num.append(numero)
    

for i in range(len(num)):
    suma += num[i]
    
promedio = suma/len(num)
mayor = []

for y in range(len(num)):
    if (num[y] > promedio):
        mayor.append(num[y])
        
print("el promedio es: ", promedio)
print("el o los numeros mayores al promedio son: ", mayor)
