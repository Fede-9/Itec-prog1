#Cargar en dos listas paralelas nombres y sueldos. Luego mostrar los nombres de las personas que ganan más de $85000.

preg1 = input("desea cargar su nombre y sueldo? ")
nombres = []
sueldos = []
ganan_mas = []

while preg1 == 'si':
    dato1 = input("escriba su nombre: ")
    nombres.append(dato1)
    dato2 = int(input("escriba el monto de sueldo: "))
    sueldos.append(dato2)
    if dato2 > 85000:
        ganan_mas.append(dato1)
    preg1 = input("desea ingresar otro nombre y sueldo? ")

print("nombres de los empleados: ", nombres)
print("sus sueldos: ", sueldos)
print("nombre de los empleados que ganan mas de 85000 pesos: ", ganan_mas)
