#Ingresar nombres en una lista, luego buscar un nombre y de encontrarlo decir en qué posición está.

preg1 = input("desea ingresar un nombre? ")
nombres = []

while preg1 == 'si':
    preg2 = input("ingrese su nombre: ")
    nombres.append(preg2)
    preg1 = input("desea ingresar otro nombre? ")

print("los nombres son: ", nombres)
posicion = nombres.index("federico")
print("el nombre Federico esta en la psocion: ", posicion)