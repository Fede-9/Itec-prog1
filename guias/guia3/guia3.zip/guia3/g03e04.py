#Dada una lista con números, crear otra con los cuadrados de esos valores.

preg1 = input("desea ingresar un numero? ")
numeros = []
cuadrado = []

while preg1 == 'si':
    preg2 = int(input("ingrese un numero: "))
    numeros.append(preg2)
    cuadrado.append(preg2*preg2)
    preg1 = input("desea ingresar otro numero? ")

print(numeros)

print(cuadrado)