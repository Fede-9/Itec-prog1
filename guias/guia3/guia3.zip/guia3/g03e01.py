#(4 de la guía 2) Pedir el ingreso de 10 números. Contar los mayores de 23.
#Almacenar los que cumplen la condición.  Mostrar los resultados.
num = []
acum = 0
for x in range (10):
    n = int(input("ingrese un numero: "))
    if n > 23:
        acum += 1
        num.append(n)
print("los numeros mayores de 23 son en total: ",acum)
print("los numeros son: ", num)